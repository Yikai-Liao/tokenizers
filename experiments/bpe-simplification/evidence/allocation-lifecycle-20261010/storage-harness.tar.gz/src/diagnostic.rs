// Experimental instrumentation; never included in production source.
use std::{
    cell::{Cell, RefCell},
    sync::atomic::{AtomicUsize, Ordering},
    time::Instant,
};
const N: usize = 12;
const NAMES: [&str; N] = [
    "vocabulary",
    "plan",
    "initial",
    "materialize",
    "select",
    "prepare",
    "apply",
    "commit",
    "drop_index",
    "drop_corpus",
    "drop_codec",
    "model",
];
static PHASE: AtomicUsize = AtomicUsize::new(0);
static CUTOFF: AtomicUsize = AtomicUsize::new(256);
#[derive(Clone, Copy, Default, serde::Serialize)]
pub(super) struct Counts {
    heap_allocations: u64,
    heap_bytes: u64,
    small_heap_allocations: u64,
    heap_frees: u64,
    freed_bytes: u64,
    arena_allocations: u64,
    arena_bytes: u64,
    arena_retires: u64,
    inline_lists: u64,
}
const ZERO: Counts = Counts {
    heap_allocations: 0,
    heap_bytes: 0,
    small_heap_allocations: 0,
    heap_frees: 0,
    freed_bytes: 0,
    arena_allocations: 0,
    arena_bytes: 0,
    arena_retires: 0,
    inline_lists: 0,
};
thread_local! {
    static COUNTS: RefCell<[Counts; N]> = const { RefCell::new([ZERO; N]) };
    static TIMES: Cell<[(f64,f64); N]> = const { Cell::new([(0.0,0.0);N]) };
}
pub(super) fn reset() {
    rayon::broadcast(|_| {
        COUNTS.with(|c| *c.borrow_mut() = [ZERO; N]);
        TIMES.set([(0.0, 0.0); N]);
    });
    PHASE.store(0, Ordering::Relaxed);
}
pub(super) fn cutoff(value: usize) {
    CUTOFF.store(value, Ordering::Relaxed);
}
pub(super) fn allocation(bytes: usize, arena: bool) {
    COUNTS.with(|c| {
        let mut rows = c.borrow_mut();
        let row = &mut rows[PHASE.load(Ordering::Relaxed)];
        if arena {
            row.arena_allocations += 1;
            row.arena_bytes += bytes as u64;
        } else {
            row.heap_allocations += 1;
            row.heap_bytes += bytes as u64;
            row.small_heap_allocations += u64::from(bytes <= CUTOFF.load(Ordering::Relaxed));
        }
    });
}
pub(super) fn retirement(bytes: usize, arena: bool) {
    COUNTS.with(|c| {
        let mut rows = c.borrow_mut();
        let row = &mut rows[PHASE.load(Ordering::Relaxed)];
        if arena {
            row.arena_retires += 1;
        } else {
            row.heap_frees += 1;
            row.freed_bytes += bytes as u64;
        }
    });
}
pub(super) fn inline() {
    COUNTS.with(|c| {
        c.borrow_mut()[PHASE.load(Ordering::Relaxed)].inline_lists += 1;
    });
}
#[repr(C)]
struct Timespec {
    seconds: i64,
    nanos: i64,
}
unsafe extern "C" {
    fn clock_gettime(clock: i32, value: *mut Timespec) -> i32;
}
fn cpu() -> f64 {
    let mut value = Timespec {
        seconds: 0,
        nanos: 0,
    };
    // SAFETY: Linux x86_64 timespec matches this repr(C) layout; the output pointer is valid.
    assert_eq!(unsafe { clock_gettime(2, &mut value) }, 0);
    value.seconds as f64 + value.nanos as f64 * 1e-9
}
pub(super) struct Span {
    id: usize,
    wall: Instant,
    cpu: f64,
}
impl Span {
    pub(super) fn new(id: usize) -> Self {
        PHASE.store(id, Ordering::Relaxed);
        Self {
            id,
            wall: Instant::now(),
            cpu: cpu(),
        }
    }
}
impl Drop for Span {
    fn drop(&mut self) {
        let wall = self.wall.elapsed().as_secs_f64();
        let cpu = cpu() - self.cpu;
        TIMES.with(|t| {
            let mut times = t.get();
            times[self.id].0 += wall;
            times[self.id].1 += cpu;
            t.set(times);
        });
    }
}
pub(super) fn report(storage: (usize, usize)) {
    if std::env::var_os("BPE_ALLOCATION_DIAGNOSTIC").is_none() {
        return;
    }
    let workers = rayon::broadcast(|_| COUNTS.with(|c| *c.borrow()));
    let counts: Vec<_> = (0..N)
        .map(|id| {
            let mut sum = ZERO;
            for worker in &workers {
                let c = worker[id];
                sum.heap_allocations += c.heap_allocations;
                sum.heap_bytes += c.heap_bytes;
                sum.small_heap_allocations += c.small_heap_allocations;
                sum.heap_frees += c.heap_frees;
                sum.freed_bytes += c.freed_bytes;
                sum.arena_allocations += c.arena_allocations;
                sum.arena_bytes += c.arena_bytes;
                sum.arena_retires += c.arena_retires;
                sum.inline_lists += c.inline_lists;
            }
            sum
        })
        .collect();
    let times = TIMES.get();
    eprintln!(
        "ALLOCATION_DIAGNOSTIC {}",
        serde_json::json!({"phases":NAMES,"times":times,"counts":counts,"small_cutoff":CUTOFF.load(Ordering::Relaxed),"retained_bump_bytes":storage.0,"retained_scratch_capacity_bytes":storage.1})
    );
}
