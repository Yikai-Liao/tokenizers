fn main(){bpe_sparse_adapter_check::probe();}
