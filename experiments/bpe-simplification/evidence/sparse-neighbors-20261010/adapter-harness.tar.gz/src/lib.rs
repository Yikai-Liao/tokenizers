#![allow(dead_code, unused_imports)]
extern crate self as tk_encode;
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
pub mod models { pub mod bpe { pub type Pair=(u32,u32); } }
mod positions;
struct BpeTrainer;
const WORD_SEPARATOR_ID:u32=u32::MAX;
fn add(count:&mut u64, amount:u64)->Result<()> { *count=count.checked_add(amount).ok_or("BPE weighted frequency exceeds u64")?; Ok(()) }
mod corpus { pub struct Corpus; pub struct Match; }
mod vocabulary { pub struct Vocabulary; }
mod index { pub struct Candidate { pub positions:super::positions::Positions } pub struct PairIndex<'a>(std::marker::PhantomData<&'a ()>); }
mod baseline;
mod sparsley;
mod xsparseset;
mod bevy;
mod cranelift;
mod indexmap;
mod cranelift_selected;
mod indexmap_selected;

use std::sync::atomic::{AtomicUsize,Ordering};
static LIVE:AtomicUsize=AtomicUsize::new(0);
struct CountAlloc;
unsafe impl std::alloc::GlobalAlloc for CountAlloc {
    unsafe fn alloc(&self,layout:std::alloc::Layout)->*mut u8 { let p=unsafe{std::alloc::System.alloc(layout)};if !p.is_null(){LIVE.fetch_add(layout.size(),Ordering::Relaxed);} p }
    unsafe fn dealloc(&self,p:*mut u8,layout:std::alloc::Layout) { LIVE.fetch_sub(layout.size(),Ordering::Relaxed);unsafe{std::alloc::System.dealloc(p,layout)} }
    unsafe fn realloc(&self,p:*mut u8,layout:std::alloc::Layout,size:usize)->*mut u8 { let q=unsafe{std::alloc::System.realloc(p,layout,size)};if !q.is_null(){LIVE.fetch_add(size,Ordering::Relaxed);LIVE.fetch_sub(layout.size(),Ordering::Relaxed);} q }
}
#[global_allocator]static ALLOC:CountAlloc=CountAlloc;
fn allocated()->usize {LIVE.load(Ordering::Relaxed)}
pub fn probe() {
    let _ = indexmap::allocation_probe(64,1); // Prewarm ahash global seed before counting container allocations.
    println!("arm,domain,groups_per_side,live_bytes,published_bytes,retained_bytes,unreleased_bytes");
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=baseline::allocation_probe(domain,groups);println!("baseline,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=sparsley::allocation_probe(domain,groups);println!("sparsley,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=xsparseset::allocation_probe(domain,groups);println!("xsparseset,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=bevy::allocation_probe(domain,groups);println!("bevy,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=cranelift::allocation_probe(domain,groups);println!("cranelift,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=indexmap::allocation_probe(domain,groups);println!("indexmap,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=cranelift_selected::allocation_probe(domain,groups);println!("cranelift-selected,{domain},{groups},{a},{b},{c},{d}");}
    for (domain,groups) in [(50000,24),(1000000,24),(50000,10000)] {let (a,b,c,d)=indexmap_selected::allocation_probe(domain,groups);println!("indexmap-selected,{domain},{groups},{a},{b},{c},{d}");}
}
