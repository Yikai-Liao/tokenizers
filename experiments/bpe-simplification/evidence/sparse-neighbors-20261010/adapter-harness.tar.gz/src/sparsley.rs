//! Compatible selection and snapshot preparation hide endpoint/event bookkeeping.
use super::{
    BpeTrainer, WORD_SEPARATOR_ID, add,
    corpus::{Corpus, Match},
    index::{Candidate, PairIndex},
    positions::{Builder, Codec, Input, Positions},
    vocabulary::Vocabulary,
};
use ahash::{AHashMap, AHashSet};
use rayon::prelude::*;
use sparsley::SparseMap;
use tk_encode::{Result, models::bpe::Pair};

/// One selected pair and resolved replacement ID, owning its candidate positions.
/// Keeping the candidate binds preparation to the cohort selected by the queue.
struct Rule {
    pair: Pair,
    replacement: u32,
    candidate: Candidate,
}

/// Priority-prefix rules selected for one joined preparation/application round.
/// Fresh rules have compatible endpoints; active-ID reuse uses a single cohort.
pub(super) struct Batch {
    rules: Vec<Rule>,
    reuse: bool,
    floor: u64,
}

/// Selection outcome for the coordinator: finish, retry the attempt, or prepare.
/// Restart discards speculative rules and requests historical-cohort training.
pub(super) enum Selection {
    Finished,
    // The whole attempt is discarded, including rules already selected in this batch.
    Restart,
    Ready(Batch),
}

/// One neighbor-edge removal and replacement birth from preparation.
/// Weights remain separate so commit preserves intermediate signed adjustments;
/// P carries birth positions, or () for separately routed metadata. Bucket
/// identifies the producer group used by owner aggregation.
pub(super) struct Change<P> {
    pub(super) removed: Pair,
    pub(super) born: Pair,
    pub(super) removed_weight: u64,
    pub(super) born_weight: u64,
    pub(super) positions: P,
    pub(super) bucket: usize,
}

/// A birth stream's publication contract: partial aggregation or complete output.
/// Complete fresh producers have already applied the frequency floor and encoded
/// their full list; partial streams need owner aggregation before publication.
pub(super) enum Birth {
    // Local fresh counts await owner aggregation before floor admission.
    // Reuse fragments instead follow the owner's per-action signed ledger.
    Partial(Builder),
    // A fresh ordinary producer covers the full candidate and has applied the floor.
    // Retained lists are ready for direct publication without another encoding pass.
    Complete(Positions),
}

impl Birth {
    pub(super) fn is_empty(&self) -> bool {
        match self {
            Self::Partial(values) => values.is_empty(),
            Self::Complete(values) => values.is_empty(),
        }
    }
}

/// Joined preparation output, owning endpoint writes and neighbor events.
/// Apply joins all writes before returning events for the coordinator's index commit.
pub(super) struct Prepared {
    jobs: Vec<Job>,
}

/// One preparation task's disjoint writes and owned neighbor-event payloads.
/// The task returns both together so no corpus mutation precedes preparation join.
struct Job {
    writes: Writes,
    changes: Vec<Change<Birth>>,
}

/// Per-task ordered neighbor groups in reusable library storage.
struct Neighbors<'a> {
    rule: &'a Rule,
    rank: usize,
    directories: &'a mut Directories,
    complete: bool,
}
/// One reusable left/right sparse map per preparation worker.
#[derive(Default)]
struct Directories {
    groups: [SparseMap<u32, Change<Builder>>; 2],
}
impl Directories {
    fn reset(&mut self) {
        for map in &mut self.groups {
            map.clear();
        }
    }
}

impl<'a> Neighbors<'a> {
    fn new(rule: &'a Rule, rank: usize, directories: &'a mut Directories, complete: bool) -> Self {
        Self {
            rule,
            rank,
            directories,
            complete,
        }
    }
    fn group(&mut self, neighbor: u32, left: bool) -> &mut Change<Builder> {
        let map = &mut self.directories.groups[usize::from(!left)];
        map.entry(neighbor).or_insert_with(|| {
            let id = self.rule.replacement;
            let pair = self.rule.pair;
            let rank = self.rank;
            Change {
                removed: if left {
                    (neighbor, pair.0)
                } else {
                    (pair.1, neighbor)
                },
                born: if left { (neighbor, id) } else { (id, neighbor) },
                removed_weight: 0,
                born_weight: 0,
                positions: Builder::default(),
                // Both sides can create (id, id); keep them in one birth cohort.
                // Other right births follow left births in the reference update order.
                bucket: 2 * rank + usize::from(!left && neighbor != id),
            }
        })
    }
    fn record(
        &mut self,
        left: bool,
        removed: u32,
        born: u32,
        position: usize,
        weight: u64,
        admit: bool,
    ) -> Result<()> {
        let group = self.group(removed, left);
        add(&mut group.removed_weight, weight)?;
        if admit {
            let group = if removed == born {
                group
            } else {
                self.group(born, left)
            };
            add(&mut group.born_weight, weight)?;
            group.positions.push_ordered(position as u64)?;
        }
        Ok(())
    }

    fn finish(self, floor: u64, codec: &Codec) -> Result<Vec<Change<Birth>>> {
        // Complete ordinary producers prune and encode before owner routing.
        // Partial jobs retain raw positions until their counts have been reduced.
        let mut result = Vec::new();
        let mut lease = codec.lease();
        // Left changes precede right changes. Reuse count actions and the resulting
        // historical cohorts observe this order even when both sides name one key.
        for map in &mut self.directories.groups {
            for mut change in map.drain().map(|(_, change)| change) {
                if self.complete && change.born_weight < floor {
                    change.positions = Builder::default();
                    change.born_weight = 0;
                }
                if change.removed_weight == 0 && change.positions.is_empty() {
                    continue;
                }
                let positions = if self.complete {
                    Birth::Complete(Positions::from_sorted(
                        Input::Builder(&change.positions),
                        &mut lease,
                    )?)
                } else {
                    Birth::Partial(change.positions)
                };
                result.push(Change {
                    removed: change.removed,
                    born: change.born,
                    removed_weight: change.removed_weight,
                    born_weight: change.born_weight,
                    bucket: change.bucket,
                    positions,
                });
            }
        }
        Ok(result)
    }
}


struct Writes;
#[test]
fn neighbor_order_reuse_floor_and_failed_task_cleanup() {
    let rule=Rule{pair:(1,2),replacement:3,candidate:Candidate{positions:Positions::default()}};
    let codec=Codec::new(1);
    let mut directories=Directories::default();
    for complete in [false,true] {
        directories.reset();
        let mut neighbors=Neighbors::new(&rule,4,&mut directories,complete);
        for (left,id,position,weight) in [(true,8,10,3),(true,6,11,2),(true,8,12,4),(false,8,13,5),(false,3,14,1)] {
            neighbors.record(left,id,id,position,weight,true).unwrap();
        }
        let output=neighbors.finish(3,&codec).unwrap();
        assert_eq!(output.iter().map(|c|c.removed).collect::<Vec<_>>(),[(8,1),(6,1),(2,8),(2,3)]);
        assert_eq!(output.iter().map(|c|c.removed_weight).collect::<Vec<_>>(),[7,2,5,1]);
        assert_eq!(output.iter().map(|c|c.bucket).collect::<Vec<_>>(),[8,8,9,8]);
        assert_eq!(output.iter().map(|c|c.born_weight).collect::<Vec<_>>(),if complete {vec![7,0,5,0]} else {vec![7,2,5,1]});
        let values:Vec<Vec<u64>>=output.iter().map(|c|match &c.positions {Birth::Partial(b)=>b.iter().collect(),Birth::Complete(p)=>p.iter().collect()}).collect();
        assert_eq!(values,if complete {vec![vec![10,12],vec![],vec![13],vec![]]} else {vec![vec![10,12],vec![11],vec![13],vec![14]]});
    }
    // An overflow can abort preparation before finish; the next reset must drop
    // its payloads and start every reused key with an empty signed ledger.
    directories.reset();
    {
        let mut failed=Neighbors::new(&rule,0,&mut directories,false);
        failed.record(true,8,8,0,u64::MAX,true).unwrap();
        assert!(failed.record(true,8,8,1,1,true).is_err());
    }
    directories.reset();
    let mut next=Neighbors::new(&rule,0,&mut directories,false);
    next.record(true,8,8,2,1,true).unwrap();
    let output=next.finish(1,&codec).unwrap();
    assert_eq!(output.len(),1);
    assert_eq!(output[0].removed_weight,1);
    assert_eq!(output[0].born_weight,1);
}
pub(crate) fn allocation_probe(domain:usize, groups:usize)->(usize,usize,usize,usize) {
    let origin=crate::allocated();
    let rule=Rule{pair:(1,2),replacement:3,candidate:Candidate{positions:Positions::default()}};
    let codec=Codec::new(1);
    let mut directories=Directories::default();
    directories.reset();
    let mut neighbors=Neighbors::new(&rule,0,&mut directories,false);
    for side in [true,false] {
        for offset in 0..groups { neighbors.group((domain-1-offset) as u32,side).removed_weight=1; }
    }
    let live=crate::allocated()-origin;
    let output=neighbors.finish(1,&codec).unwrap();
    let published=crate::allocated()-origin;
    drop(output);
    let retained=crate::allocated()-origin;
    drop(directories);drop(codec);
    let released=crate::allocated()-origin;
    (live,published,retained,released)
}
