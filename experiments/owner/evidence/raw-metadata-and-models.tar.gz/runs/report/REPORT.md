# Experiment 43b11cd55c82c53b1a8a35afa4e5151124b5acc3c013618ff8bf3bad4a0626d3

Mode: core. Complete paired blocks: 6/6.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| zh256-whitespace-v50000 | 4 | blocks | 1.0372230227381503 |
| zh256-whitespace-v50000 | 4 | bucket | 1.1405793929261028 |
| zh256-whitespace-v50000 | 4 | epoch | 16.224252037455084 |
| zh256-whitespace-v50000 | 4 | stable | 1.5121722668454805 |
| en256-whitespace-v50000 | 4 | blocks | 1.0440927333237289 |
| en256-whitespace-v50000 | 4 | bucket | 1.0100996189384603 |
| en256-whitespace-v50000 | 4 | epoch | 10.438786979278575 |
| en256-whitespace-v50000 | 4 | stable | 1.8437929703326204 |

## Failures

None.
