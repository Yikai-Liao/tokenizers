# Experiment ebbe26a8239522cbbe2a4b6deaa79e0f8725776265f92e78615a49de80c6c359

Mode: core. Complete paired blocks: 6/6.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| zh256-whitespace-v50000 | 4 | pipeline | 1.0226457094928336 |
| zh256-whitespace-v50000 | 4 | sortcount | 1.0042132196454963 |
| en256-whitespace-v50000 | 4 | pipeline | 1.1169232541630196 |
| en256-whitespace-v50000 | 4 | sortcount | 1.0423022613765067 |

## Failures

None.
