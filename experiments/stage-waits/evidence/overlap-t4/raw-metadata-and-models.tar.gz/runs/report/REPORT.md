# Experiment 72a2d25dd1763a220e58d3a03b048cb4da442b2eea2be395ee4bbf383ed8897f

Mode: core. Complete paired blocks: 6/6.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| zh256-whitespace-v50000 | 4 | overlap | 0.9950127560180166 |
| en256-whitespace-v50000 | 4 | overlap | 0.9733764760578463 |

## Failures

None.
