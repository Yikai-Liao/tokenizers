# Experiment 2f01456d64ecb6e89a045412012e2788627c362e46dc7b8e798ca650bbff8726

Mode: core. Complete paired blocks: 2/2.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| zh256-whitespace-v50000 | 4 | diagnostic | 0.9517947793053344 |
| en256-whitespace-v50000 | 4 | diagnostic | 0.8838704058726721 |

## Failures

None.
